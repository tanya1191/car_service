package com.car_repair_shop.car_repair.exceptions;

public class DateParseException extends Exception {

    public DateParseException(String msg) {
        super(msg);
    }
}
