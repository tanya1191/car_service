package com.car_repair_shop.car_repair.forms.user;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class SearchForm {

    private String email;
    private String vat;
}
