package com.car_repair_shop.car_repair.exceptions;

public class VehicleNotFoundException extends Exception {

    public VehicleNotFoundException(String msg){ super(msg);}
}
