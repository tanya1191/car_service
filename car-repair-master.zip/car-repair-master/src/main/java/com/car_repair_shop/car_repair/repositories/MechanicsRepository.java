package com.car_repair_shop.car_repair.repositories;

import com.car_repair_shop.car_repair.domain.Mechanics;
import com.car_repair_shop.car_repair.domain.Vehicle;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MechanicsRepository extends CrudRepository<Mechanics, Long> {


}
