package com.car_repair_shop.car_repair.exceptions;

public class UserNotFoundException extends Exception{

    public UserNotFoundException(String msg) {
        super(msg);
    }
}
