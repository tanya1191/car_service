package com.car_repair_shop.car_repair.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.validator.constraints.Email;

import javax.persistence.*;

@Entity
@NoArgsConstructor
@Getter
@Setter
public class Mechanics{

    @Id
    @Column(name = "idmechanics", nullable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long idmechanics;

    @Column(nullable = false, unique = true, length = 60)
    @Email
    private String name;

    @Column(nullable = false)
    private String mobile;
    
    @Column(nullable = false)
    private String pincode;
    
    @Column(nullable = false)
    private String expertise;
    
    @Column(nullable = false)
    private String rate;

    @Column(nullable = false)
    private String location;  
    @Column(nullable = false)
    private String distance;
    
    @Column(nullable = false)
    private String time;// value true means ADMIN - value false means USER


}
